package com.practice.atlassianDesignCode;


/**
 * interface MostPopular {

    void increasePopularity(Integer contentId);

    Integer mostPopular(); --> greater than 0 if all content =0 return -1

    void decreasePopularity(Integer contentId);

}
 */

public class AtlassianDSA {

	public static void main(String[] args) {
		
	}
}
