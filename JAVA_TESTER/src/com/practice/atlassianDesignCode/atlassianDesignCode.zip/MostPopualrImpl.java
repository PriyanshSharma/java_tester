package com.practice.atlassianDesignCode;

import java.util.Comparator;
import java.util.HashMap;
import java.util.Map;
import java.util.TreeMap;

public class MostPopualrImpl implements MostPopular {

	Map<Integer,Integer> map = new HashMap<Integer, Integer>();
	
	TreeMap<Integer, Integer> idToPopularityMap ;
	
	
	@Override
	public void increasePopularity(Integer contentId) {
		
		if (map.containsKey(contentId)) {
			map.put(contentId, map.getOrDefault(1, contentId)+1);
		}
		
		map.put(contentId, 1);
		
		

	}

	@Override
	public Integer mostPopular() {
		
		
		
		idToPopularityMap = new TreeMap<Integer, Integer>((k1,k2) -> {
			int cmp = map.get(k1).compareTo(map.get(k2));
			return cmp!=0 ? cmp : k1.compareTo(k2);
		});
		
		idToPopularityMap.putAll(map);
		
		
		return null;
	}

	@Override
	public void decreasePopularity(Integer contentId) {
		
		if (map.containsKey(contentId) && map.get(contentId)>0) {
			
			map.put(contentId, map.getOrDefault(1, contentId)-1);
			
			if (map.get(contentId)==0) {
				map.remove(contentId);
			}
		}
		
		System.out.println("Contentid not present");
	}

	record Pair(int id,int freq) {}
}
